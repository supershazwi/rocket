const populateModal = (event) => {
  const description = document.getElementById(`description_${event.target.id}`).innerHTML.trim();
  document.getElementById('modal-body').innerHTML = description;
};