'use strict';
const { faker } = require('@faker-js/faker');

module.exports = {
  up: async (queryInterface, Sequelize) => {
    const products = [];

    for (let index = 0; index < 50; index++) {
      products.push({
        name: faker.commerce.product(),
        description: faker.commerce.productDescription(),
        created_at: new Date(),
        updated_at: new Date(),
      });
    }

    await queryInterface.bulkInsert('items', products, { returning: true, });
  },

  down: async (queryInterface, Sequelize) => {
    
  }
};
