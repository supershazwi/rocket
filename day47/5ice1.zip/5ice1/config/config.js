module.exports = {
  development: {
    username: 'supershazwi',
    password: 'noobies',
    database: 'modal_grocery_development',
    host: '127.0.0.1',
    dialect: 'postgres',
  },
};
